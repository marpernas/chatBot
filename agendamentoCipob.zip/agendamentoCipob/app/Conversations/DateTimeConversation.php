<?php

namespace App\Conversations;

use Carbon\Carbon;
use BotMan\BotMan\Messages\Incoming\Answer;
use BotMan\BotMan\Messages\Outgoing\Question;
use BotMan\BotMan\Messages\Outgoing\Actions\Button;
use BotMan\BotMan\Messages\Conversations\Conversation;

class DateTimeConversation extends Conversation
{
    public function askDate()
    {
        $availableDates = [
            Carbon::today()->addDays(1),
            Carbon::today()->addDays(2),
            Carbon::today()->addDays(3)         ];

        $question = Question::create('selecione uma data')
            ->callbackId('select_date')
            ->addButtons([
                Button::create($availableDates[0]->format('d M'))->value($availableDates[0]->format('d-m-Y')),
                Button::create($availableDates[1]->format('d M'))->value($availableDates[1]->format('d-m-Y')),
                Button::create($availableDates[2]->format('d M'))->value($availableDates[2]->format('d-m-Y')),
            ]);

        $this->ask($question, function(Answer $answer) {
            if ($answer->isInteractiveMessageReply()) {
                $this->bot->userStorage()->save([
                    'date' => $answer->getValue(),
                ]);

                $this->askTime();
            }
        });
    }

    public function askTime()
    {
        $question = Question::create('selecione uma data abaixo')
            ->callbackId('select_time')
            ->addButtons([
                Button::create('9 horas')->value('9 horas'),
                Button::create('10 horas')->value('10 horas'),
                Button::create('13 horas')->value('13 horas'),
            ]);

        $this->ask($question, function(Answer $answer) {
            if ($answer->isInteractiveMessageReply()) {
                $this->bot->userStorage()->save([
                    'timeSlot' => $answer->getValue(),
                ]);
            }
            $this->bot->startConversation(new BookingConversation());
        });
    }

    public function run()
    {
        $this->askDate();
    }
}
