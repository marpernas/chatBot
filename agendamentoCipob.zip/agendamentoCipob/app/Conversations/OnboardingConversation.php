<?php

namespace App\Conversations;

use Validator;
use BotMan\BotMan\Messages\Incoming\Answer;
use BotMan\BotMan\Messages\Outgoing\Question;
use BotMan\BotMan\Messages\Outgoing\Actions\Button;
use BotMan\BotMan\Messages\Conversations\Conversation;

class OnboardingConversation extends Conversation
{
    
    public function askName()
    {
        
        $this->ask('Olá qual o teu nome?', function(Answer $answer) {
        
            $this->bot->userStorage()->save([
                'name' => $answer->getText(),
            ]);
            
            $this->say('Muito bom falar com você '. $answer->getText());
            
            $this->ask('Sua dúvida é sobre, conformidade? Responda com <b>sim</b> ou <b>não</b>.',[
                [
                    'pattern' => 'sim|SIM|Sim',
                    'callback' => function(Answer $answer){
                        $this->say('Ótimo selecione as opções abaixo:');
                        $this->bot->startConversation(new SelectServiceConversation()); // Trigger the next conversation
                    }
                ],

                [
                   'pattern' => 'não|nao|NÃO',
                   'callback'=> function(Answer $answer){
                       $this->say('hummm, então por enquanto eu não posso te ajudar, mas meus colegas estão te esperando aqui');
                   } 
                ]
            ]);            
        });
    }

    public function run()
    {
        $this->askName();
    }
}
