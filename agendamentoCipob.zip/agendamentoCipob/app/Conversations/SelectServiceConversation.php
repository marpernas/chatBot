<?php

namespace App\Conversations;
use App\Contas;
use BotMan\BotMan\Messages\Incoming\Answer;
use BotMan\BotMan\Messages\Outgoing\Question;
use BotMan\BotMan\Messages\Outgoing\Actions\Button;
use BotMan\BotMan\Messages\Conversations\Conversation;


class SelectServiceConversation extends Conversation
{

    protected $valorService;
    protected $respostas;

    public function askService()
    {
        $question = Question::create('Qual o tipo de serviço que você está procurando?')
            ->callbackId('select_service')
            ->addButtons([
                Button::create('Conformidade')->value('Conformidade'),
                Button::create('Contestação de Parecer')->value('Parecer'),
                Button::create('Operação 006')->value('Operacao 006'),
                Button::create('Reanalise')->value('Reanalise'),
            ]);

                $this->ask($question, function(Answer $answer) {
                    if ($answer->isInteractiveMessageReply()) {
                        $this->bot->userStorage()->save([
                            'service' => $answer->getValue(),
                        ]);
                    }

                    $valorService = $answer->getValue();
                    $this->say('Ok, eu vi que você quer saber sobre: ' .$valorService. '.');

                    $this->ask('Muito bem ! Agora para eu te ajudar poderia informar a Agência/Operação/Conta. Detalhe siga o modelo 1234/001/123456678-9', function(Answer $answer){
                        $this->bot->userStorage()->save([
                            'answer' => $answer->getText(),
                        ]);

                        $this->ask('Ok, eu vi que saber sobre' . $answer . 'Você esta de acordo? Confirme com "sim" ou "não"',[
                                [
                                    'pattern' => 'sim|SIM|Sim',
                                    'callback' => function(Answer $answer){
                                        $respostas = Contas::all();

                                        foreach ($respostas as $resposta) {
                                            $this->say('Acho que encontrei alguma coisa, veja você:  '.$resposta->agencia);
                                    }       
                                        }
                                                       
                                ],

                                [
                                    'pattern' => 'não|nao|NÃO',
                                    'callback'=> function(Answer $answer){
                                        $this->say('hummm, então por enquanto eu não posso te ajudar, mas meus colegas estão te esperando aqui');
                                    } 
                                ]
                            ]);      

                        });
                        
                    });         
     }


    
    public function run()
    {
        $this->askService();
    }
}
