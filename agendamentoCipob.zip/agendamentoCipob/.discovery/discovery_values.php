<?php
return array (
  'botman/driver-config' => 
  array (
    0 => 'stubs/web.php',
  ),
  'botman/driver' => 
  array (
    0 => 'BotMan\\Drivers\\Web\\WebDriver',
  ),
);
