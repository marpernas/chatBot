<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Novo Portal CIPOB-CT</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,400i,600,700" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <style>
     .navCipob:{
         color: #ffffff;
         font-weigth: bold;
     }
    </style>
</head>

<!-- Menu Navegacao -->

<nav class="navbar navbar-expand-lg navbar-light py-4" style="background-color: #0470B4;" id="navCipob">
  <a class="navbar-brand" href="#" >CIPOB-CT</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Nossos Canais <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Missão</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="#">Institucional</a>
      </li>
    </ul>
    
  </div>
</nav>


<!-- FIM Menu Navegacao -->


<!-- PRINCIPAL-->

<body>

<div class="container">
    <div class="content">
        
    </div>
</div>

<script>
    var botmanWidget = {
        title: 'MonaBot',
        introMessage: 'Olá, eu sou a MonaBot',
        mainColor: '#0470B4',
        bubbleBackground: '#CA8815',
        aboutText: '',
        bubbleAvatarUrl: '',
        aboutText: '',
        
    };

</script>
<script src='https://cdn.jsdelivr.net/npm/botman-web-widget@0/build/js/widget.js'></script>
</body>
</html>