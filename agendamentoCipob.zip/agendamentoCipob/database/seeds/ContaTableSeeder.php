<?php

use Illuminate\Database\Seeder;
use App\Contas;

class ContaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Contas::create([
            'agencia' => 'Agua Verde2',
            'operacao' => '0012',
            'conta' => '7001232',
            'situacao' => 'inconforme falta documentos'
        ]);
    }
}
